<?php
require 'config/koneksi.php';

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 1. Capture data from form
    $nama = $_POST['fullname'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // 2. Hash the password for security
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // 3. Prepare SQL Statement (matches your 'pelanggan' table)
    $stmt = $conn->prepare("INSERT INTO pelanggan (nama, email, password) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $nama, $email, $hashed_password);

    // 4. Execute and check
    if ($stmt->execute()) {
        echo "<script>alert('Registration Successful! Please Login.'); window.location.href='login.php';</script>";
    } else {
        $message = "Error: " . $conn->error; // Usually happens if email is duplicate
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Page - Bali Events</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --color-primary-orange: #e67e22;
            --color-dark-bg: rgba(0, 0, 0, 0.75);
            --color-light-text: #fff;
            --color-input-bg: #fff;
            --color-label: #ccc;
            /* PERBAIKAN: Tambahkan definisi dark text */
            --color-dark-text: #333;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            /* Same as login for consistency */
            background: url('assets/Background/Background2.png') no-repeat center center fixed;
            background-size: cover;
            font-family: 'Roboto', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            color: #333;
        }

        body::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.3);
            z-index: 1;
        }

        /* Container Register Form */
        .register-container {
            position: relative;
            z-index: 2;
            width: 90%;
            max-width: 400px;
            padding: 40px;

            background-color: rgba(51, 51, 51, 0.9);
            backdrop-filter: blur(4px);
            border-radius: 8px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
            text-align: center;
        }

        .register-container h2 {
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 30px;
            letter-spacing: 1px;
            text-transform: uppercase;
            color: var(--color-light-text);
        }

        .input-group {
            text-align: left;
            margin-bottom: 20px;
        }

        .input-group label {
            display: block;
            margin-bottom: 5px;
            color: var(--color-label);
            font-size: 0.9rem;
            font-weight: 300;
        }

        .input-group input[type="text"],
        .input-group input[type="email"],
        .input-group input[type="password"] {
            width: 100%;
            padding: 12px 15px;
            border: none;
            border-radius: 4px;
            background-color: var(--color-input-bg);
            /* Memastikan teks yang diketik berwarna gelap */
            color: var(--color-dark-text);
            font-size: 1rem;
            outline: none;
            transition: border-color 0.3s;
        }

        .input-group input:focus {
            border: 2px solid var(--color-primary-orange);
        }

        .register-btn {
            width: 100%;
            padding: 12px 15px;
            background-color: var(--color-primary-orange);
            color: var(--color-light-text);
            border: none;
            border-radius: 4px;
            font-size: 1rem;
            font-weight: bold;
            cursor: pointer;
            text-transform: uppercase;
            margin-top: 10px;
            transition: background-color 0.3s;
        }

        .register-btn:hover {
            background-color: #d66a1a;
        }

        .login-link {
            font-size: 0.9rem;
            color: var(--color-label);
            margin-top: 20px;
        }

        .login-link a {
            color: var(--color-primary-orange);
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s;
        }

        .login-link a:hover {
            color: #fff;
        }
    </style>
</head>

<body>

    <div class="register-container">
        <h2>SIGN UP</h2>
        <form method="POST">
            <div class="input-group">
                <label for="fullname">Full Name</label>
                <input type="text" id="fullname" name="fullname" required>
            </div>

            <div class="input-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>
            </div>

            <div class="input-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>

            <button type="submit" class="register-btn">SIGN UP</button>
        </form>

        <p class="login-link">
            Already have an account? <a href="login.php">Log in here!</a>
        </p>
    </div>

</body>

</html>